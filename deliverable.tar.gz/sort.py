#!/usr/bin/python

import os, io, sys

"""
While not as efficent as it could be, the sort below operates by each number read from the input file
into a target output file in a random locations chosen by weighting the number itself. The file is
then read out in order into the output. This is representative of a one-pass sort.
There are some limitations with this approach but it should hopefully satisfy the requirements to some
extent.

Pros:
Light on memory
Fast with small-medium sorting

Cons:
Slow with large numbers
Processor intensive
Disk intensive
Is limited by the inode implementation on target system (tested on Linux/x86)


-Roderick Timmerman
"""

if (len(sys.argv) < 2):
	print "Usage:\n\n\tpython sort.py FILENAME\n"
	sys.exit(1)

infile_path = sys.argv[1]

def parse(data):
    return map(lambda d: int(d), data.split(','))

with io.open(infile_path, 'r') as infile, io.open('./temp.bin', 'w+b') as tmpfile, io.open('./final.csv', 'w') as outfile:
    comma_n = 0
    buff = ''
    for c in iter(infile.read()):
        if (c == ','):
            n = int(buff)
            buff = ''
            tmpfile.seek(n * 9, os.SEEK_SET);
            tmpfile.write(str(n))
            
        if (c != ','):
            buff += c
    tmpfile.seek(0, os.SEEK_SET)
    n = ''
    for c in iter(tmpfile.read()):
        if (c != b'\0'):
            n += c
        elif (len(n) > 0):
            outfile.write(unicode(str(n) + ','))
            n = ''
        else:
            n = ''
outfile.close()
infile.close()
tmpfile.close()

os.unlink('./temp.bin')
